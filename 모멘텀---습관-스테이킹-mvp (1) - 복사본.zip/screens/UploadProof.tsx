
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storage';
import { Challenge, Proof } from '../types';
import { submitProofToAI } from '../services/mockApi';
import BottomNav from '../components/BottomNav';

interface UploadProofProps {
  challenges: Challenge[];
  onUploaded: () => void;
}

const UploadProof: React.FC<UploadProofProps> = ({ challenges, onUploaded }) => {
  const navigate = useNavigate();
  const activeChallenges = challenges.filter(c => c.status === 'active');
  const [selectedChallengeId, setSelectedChallengeId] = useState(activeChallenges[0]?.id || '');
  const [note, setNote] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!selectedChallengeId) return alert('매칭된 챌린지를 선택해주세요.');
    if (!imagePreview) return alert('인증 사진을 찍거나 업로드해주세요.');
    
    setIsUploading(true);
    
    try {
      const aiResult = await submitProofToAI(imagePreview);
      
      if (aiResult.success) {
        const newProof: Proof = {
          id: Math.random().toString(36).substr(2, 9),
          challengeId: selectedChallengeId,
          imageUrl: imagePreview,
          note: note,
          timestamp: new Date().toISOString()
        };
        
        storage.addProof(newProof);
        
        // 코인 보상 지급
        const user = storage.getUser();
        storage.setUser({...user, balance: user.balance + 100});
        
        onUploaded();
        
        // 피드백 반영: 홈으로 가지 않고 즉시 상세 페이지(매칭 보드)로 이동
        navigate(`/challenge-details/${selectedChallengeId}`);
      }
    } catch (err) {
      alert('업로드에 실패했습니다. 다시 시도해주세요.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light text-slate-900 font-body animate-in fade-in duration-500">
      <nav className="sticky top-0 z-50 glass-header border-b border-slate-100">
        <div className="flex items-center justify-between p-4 h-16">
          <button onClick={() => navigate(-1)} className="size-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-100">
            <span className="material-symbols-outlined font-bold">arrow_back</span>
          </button>
          <h1 className="text-sm font-black tracking-widest text-slate-800 uppercase">인증 데이터 제출</h1>
          <div className="size-10"></div>
        </div>
      </nav>

      <main className="flex-1 w-full p-6 space-y-8 pb-32">
        <header className="space-y-2">
          <h2 className="text-2xl font-black text-slate-900 leading-tight">오늘의 약속을<br /><span className="text-primary">증명해 주세요</span></h2>
          <div className="pt-4">
             <label className="block text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Target Match</label>
             <select 
               value={selectedChallengeId}
               onChange={(e) => setSelectedChallengeId(e.target.value)}
               className="w-full bg-white rounded-2xl p-4 border border-slate-100 text-sm font-bold focus:ring-2 focus:ring-primary text-slate-800 shadow-soft appearance-none"
             >
               {activeChallenges.map(c => (
                 <option key={c.id} value={c.id}>{c.title}</option>
               ))}
               {activeChallenges.length === 0 && <option>참여 중인 매칭 없음</option>}
             </select>
          </div>
        </header>

        {/* Camera UI Section */}
        <div className="relative aspect-square rounded-[2.5rem] border-2 border-dashed border-slate-200 bg-white flex flex-col items-center justify-center gap-4 overflow-hidden group shadow-soft transition-all hover:border-primary/30">
          {imagePreview ? (
            <>
              <img src={imagePreview} className="w-full h-full object-cover" alt="preview" />
              <button 
                onClick={() => setImagePreview(null)}
                className="absolute top-4 right-4 bg-black/50 backdrop-blur-md size-10 rounded-full text-white flex items-center justify-center active:scale-90 transition-all"
              >
                <span className="material-symbols-outlined font-bold">close</span>
              </button>
            </>
          ) : (
            <>
              <label className="cursor-pointer flex flex-col items-center gap-4 w-full h-full justify-center">
                <div className="size-20 bg-primary-light rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-inner-soft">
                  <span className="material-symbols-outlined text-primary text-4xl font-bold">photo_camera</span>
                </div>
                <div className="text-center">
                  <p className="font-black text-lg text-slate-800">인증 사진 촬영</p>
                  <p className="text-xs text-slate-400 font-medium">당신의 자산을 지키는 유일한 방법</p>
                </div>
                <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleImageChange} />
              </label>
            </>
          )}
          <div className="absolute top-4 left-4 bg-accent-yellow text-slate-900 px-3 py-1 rounded-full text-[10px] font-black shadow-lg border border-white/20 animate-bounce">+100 COIN</div>
        </div>

        <div className="space-y-3">
          <label className="block text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest px-1">Note</label>
          <textarea 
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="w-full rounded-3xl bg-white border-slate-100 focus:ring-2 focus:ring-primary p-5 text-sm font-medium min-h-[120px] text-slate-700 shadow-soft placeholder:text-slate-300 transition-all" 
            placeholder="인증과 함께 짧은 소감을 남겨보세요."
          />
        </div>

        <button 
          onClick={handleSubmit} 
          disabled={isUploading || !selectedChallengeId || !imagePreview}
          className={`w-full font-black text-lg py-5 rounded-[2rem] shadow-floating flex items-center justify-center gap-3 transition-all active:scale-[0.98] ${isUploading || !imagePreview ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-primary text-white'}`}
        >
          {isUploading ? (
            <>
              <span className="material-symbols-outlined animate-spin">sync</span>
              AI 정밀 검증 중...
            </>
          ) : (
            <>
              인증 완료 및 자산 보호
              <span className="material-symbols-outlined font-black">shield_check</span>
            </>
          )}
        </button>
      </main>
      <BottomNav />
    </div>
  );
};

export default UploadProof;
