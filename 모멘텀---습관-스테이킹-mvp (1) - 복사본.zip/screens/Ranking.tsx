
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import { User } from '../types';
import { getRankings } from '../services/storage';

interface RankingProps {
  user: User;
}

const Ranking: React.FC<RankingProps> = ({ user }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'total' | 'streak'>('total');
  const rankings = getRankings();

  // Top 3 separation
  const top3 = rankings.slice(0, 3);
  const rest = rankings.slice(3);

  return (
    <div className="pb-40 bg-background-light min-h-screen text-black font-body animate-in fade-in duration-500">
      {/* Sticky Header */}
      <nav className="sticky top-0 z-50 glass-header px-4 py-4 border-b border-slate-100">
        <div className="flex items-center justify-between mb-4">
           <h1 className="text-xl font-black text-black">수호자 랭킹</h1>
           <button className="size-10 rounded-full bg-slate-50 flex items-center justify-center text-black/40">
              <span className="material-symbols-outlined font-bold">military_tech</span>
           </button>
        </div>
        
        <div className="flex p-1 bg-slate-100 rounded-2xl">
           <button 
             onClick={() => setActiveTab('total')}
             className={`flex-1 py-2 rounded-xl text-xs font-black transition-all ${activeTab === 'total' ? 'bg-white shadow-soft text-primary' : 'text-black/40'}`}
           >
             누적 수호 코인
           </button>
           <button 
             onClick={() => setActiveTab('streak')}
             className={`flex-1 py-2 rounded-xl text-xs font-black transition-all ${activeTab === 'streak' ? 'bg-white shadow-soft text-primary' : 'text-black/40'}`}
           >
             최장 스트릭
           </button>
        </div>
      </nav>

      <main className="p-6">
        {/* Podium Area (Top 3) */}
        <section className="flex items-end justify-center gap-4 mb-12 mt-4">
           {/* Rank 2 */}
           <div className="flex flex-col items-center gap-3">
              <div className="relative">
                 <div className="size-16 rounded-full border-4 border-slate-200 p-0.5 shadow-lg">
                    <img src={top3[1].avatar} className="w-full h-full rounded-full object-cover" alt="rank2" />
                 </div>
                 <div className="absolute -bottom-2 -right-2 size-7 bg-slate-200 text-black/60 rounded-full flex items-center justify-center font-black text-xs border-2 border-white">2</div>
              </div>
              <div className="text-center">
                 <p className="text-xs font-black text-black truncate w-16">{top3[1].name}</p>
                 <p className="text-[10px] font-bold text-black/40">{(top3[1].score/1000).toFixed(1)}k</p>
              </div>
           </div>

           {/* Rank 1 */}
           <div className="flex flex-col items-center gap-4">
              <div className="relative">
                 <span className="material-symbols-outlined absolute -top-8 left-1/2 -translate-x-1/2 text-accent-yellow text-3xl animate-bounce">workspace_premium</span>
                 <div className="size-24 rounded-full border-4 border-accent-yellow p-1 shadow-floating ring-4 ring-accent-yellow/10">
                    <img src={top3[0].avatar} className="w-full h-full rounded-full object-cover" alt="rank1" />
                 </div>
                 <div className="absolute -bottom-2 -right-2 size-8 bg-accent-yellow text-black rounded-full flex items-center justify-center font-black text-sm border-2 border-white">1</div>
              </div>
              <div className="text-center">
                 <p className="text-sm font-black text-black truncate w-20">{top3[0].name}</p>
                 <p className="text-xs font-black text-primary">{(top3[0].score/1000).toFixed(1)}k</p>
              </div>
           </div>

           {/* Rank 3 */}
           <div className="flex flex-col items-center gap-3">
              <div className="relative">
                 <div className="size-16 rounded-full border-4 border-orange-200 p-0.5 shadow-lg">
                    <img src={top3[2].avatar} className="w-full h-full rounded-full object-cover" alt="rank3" />
                 </div>
                 <div className="absolute -bottom-2 -right-2 size-7 bg-orange-200 text-orange-800 rounded-full flex items-center justify-center font-black text-xs border-2 border-white">3</div>
              </div>
              <div className="text-center">
                 <p className="text-xs font-black text-black truncate w-16">{top3[2].name}</p>
                 <p className="text-[10px] font-bold text-black/40">{(top3[2].score/1000).toFixed(1)}k</p>
              </div>
           </div>
        </section>

        {/* Ranking List */}
        <section className="space-y-3">
           {rest.map((r, idx) => (
             <div key={r.id} className="bg-white rounded-2xl p-4 border border-slate-100 flex items-center gap-4 shadow-soft active:scale-[0.98] transition-all">
                <span className="text-sm font-black text-black/20 w-5">{idx + 4}</span>
                <img src={r.avatar} className="size-10 rounded-full border border-slate-100" alt={r.name} />
                <div className="flex-1">
                   <h4 className="text-sm font-bold text-black">{r.name}</h4>
                   <p className="text-[10px] text-black/40 font-medium">Streak: {r.streak}일</p>
                </div>
                <div className="text-right flex items-center gap-3">
                   <div>
                      <p className="text-sm font-black text-black">{r.score.toLocaleString()}</p>
                      <p className="text-[9px] font-black uppercase text-primary">Coins Safe</p>
                   </div>
                   <span className={`material-symbols-outlined text-sm ${r.change === 'up' ? 'text-primary' : r.change === 'down' ? 'text-danger' : 'text-black/20'}`}>
                      {r.change === 'up' ? 'arrow_upward' : r.change === 'down' ? 'arrow_downward' : 'remove'}
                   </span>
                </div>
             </div>
           ))}
        </section>
      </main>

      {/* Floating My Rank Card */}
      <div className="fixed bottom-24 left-6 right-6 z-40 animate-in slide-in-from-bottom duration-700">
         <div className="bg-black rounded-[2rem] p-5 shadow-floating border border-white/10 flex items-center gap-4">
            <div className="size-10 rounded-full bg-primary-light flex items-center justify-center text-primary font-black text-xs border border-primary/20">
               12
            </div>
            <img src={user.avatarUrl} className="size-10 rounded-full border border-white/20" alt="me" />
            <div className="flex-1">
               <h4 className="text-sm font-bold text-white">나 (나도현)</h4>
               <p className="text-[10px] text-white/40 font-medium tracking-wide">상위 15% 이내 진입 중</p>
            </div>
            <div className="text-right">
               <p className="text-sm font-black text-primary">50,000</p>
               <p className="text-[9px] font-black text-white/30 uppercase">Coins Protected</p>
            </div>
         </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Ranking;
