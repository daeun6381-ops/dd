
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import { User, Challenge } from '../types';

interface DashboardProps {
  user: User;
  challenges: Challenge[];
}

const Dashboard: React.FC<DashboardProps> = ({ user, challenges }) => {
  const navigate = useNavigate();
  const activeChallenges = challenges.filter(c => c.status === 'active');
  const totalProgress = activeChallenges.length > 0 
    ? Math.round(activeChallenges.reduce((acc, c) => acc + c.progress, 0) / activeChallenges.length)
    : 0;

  return (
    <div className="pb-32 bg-background-light min-h-screen text-black font-body animate-in fade-in duration-500">
      {/* Refined Header */}
      <header className="p-5 flex items-center justify-between glass-header sticky top-0 z-40 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div 
            onClick={() => navigate('/profile')}
            className="size-10 rounded-full bg-primary-light p-0.5 shadow-sm active:scale-95 transition-transform cursor-pointer border border-primary/20"
          >
            <img src={user.avatarUrl} alt="avatar" className="w-full h-full rounded-full object-cover" />
          </div>
          <div>
            <p className="text-[10px] font-extrabold text-black/60 uppercase tracking-widest leading-none mb-0.5">Momentum Hub</p>
            <h1 className="text-base font-bold text-black">{user.name}님, 환영해요!</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => navigate('/lockscreen')}
            className="size-10 rounded-full bg-white flex items-center justify-center shadow-soft border border-slate-100 text-black active:scale-90 transition-all"
            title="잠금화면 모드"
          >
            <span className="material-symbols-outlined text-xl">screen_lock_portrait</span>
          </button>
          <div className="bg-white px-4 py-2 rounded-2xl flex items-center gap-2 shadow-soft border border-slate-100">
            <span className="material-symbols-outlined text-accent-yellow text-xl fill-1">monetization_on</span>
            <span className="font-extrabold text-sm text-black">{user.balance.toLocaleString()}</span>
          </div>
        </div>
      </header>

      <main className="p-5 space-y-8">
        {/* Momentum Progress Card */}
        <section className="relative overflow-hidden bg-white rounded-3xl p-8 shadow-soft border border-slate-50">
          <div className="absolute top-0 right-0 p-6 opacity-5">
             <span className="material-symbols-outlined text-8xl text-primary">analytics</span>
          </div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-6">
               <div>
                  <h2 className="text-3xl font-black text-black tracking-tight">전체 달성률 {totalProgress}%</h2>
                  <p className="text-black/60 text-sm font-medium mt-1">{activeChallenges.length}개의 목표가 진행 중입니다</p>
               </div>
            </div>
            
            <div className="w-full bg-slate-100 rounded-full h-3 mb-4 overflow-hidden">
               <div className="bg-primary h-full rounded-full transition-all duration-1000 ease-out shadow-[0_0_12px_rgba(34,195,168,0.3)]" style={{width: `${totalProgress}%`}}></div>
            </div>

            <div className="flex justify-between items-center">
               <div className="flex -space-x-2">
                  {[1,2,3].map(i => (
                    <div key={i} className="size-7 rounded-full border-2 border-white bg-slate-200 overflow-hidden shadow-sm">
                       <img src={`https://picsum.photos/seed/user${i}/50/50`} alt="user" />
                    </div>
                  ))}
                  <div className="size-7 rounded-full border-2 border-white bg-primary-light flex items-center justify-center text-[8px] font-black text-primary">+1.2k</div>
               </div>
               <p className="text-[10px] font-extrabold text-primary uppercase tracking-widest bg-primary-light px-3 py-1 rounded-full">Active Matching</p>
            </div>
          </div>
        </section>

        {/* Action: Waiting for Proof */}
        {activeChallenges.length > 0 && (
          <section className="space-y-4">
             <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-black text-black/40 uppercase tracking-widest">오늘의 인증 대기</h3>
                <span className="text-[10px] font-bold text-accent-blue flex items-center gap-1 bg-accent-blue/5 px-2 py-1 rounded-lg">
                   <span className="size-1.5 rounded-full bg-accent-blue animate-pulse"></span> 08:42:15 남음
                </span>
             </div>
             <div className="grid grid-cols-1 gap-3">
                {activeChallenges.slice(0, 2).map(challenge => (
                  <button 
                    onClick={() => navigate('/upload-proof')} 
                    key={challenge.id}
                    className="flex items-center gap-4 p-5 bg-white rounded-2xl hover:bg-slate-50 active:scale-[0.98] transition-all border border-slate-100 shadow-soft"
                  >
                    <div className="size-12 rounded-xl bg-primary-light flex items-center justify-center border border-primary/10">
                       <img src={challenge.imageUrl} className="size-8 object-cover rounded-lg" alt="icon" />
                    </div>
                    <div className="flex-1 text-left">
                       <h4 className="font-bold text-black text-sm">{challenge.title}</h4>
                       <p className="text-[10px] text-primary font-extrabold uppercase tracking-tight">수호 코인: {challenge.deposit.toLocaleString()}</p>
                    </div>
                    <span className="material-symbols-outlined text-black/20 font-bold">arrow_forward_ios</span>
                  </button>
                ))}
             </div>
          </section>
        )}

        {/* Horizontal Matching List */}
        <section className="space-y-4">
           <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-black text-black/40 uppercase tracking-widest">나의 매칭 목록</h3>
              <Link to="/community" className="text-xs font-extrabold text-primary flex items-center gap-1">탐색 <span className="material-symbols-outlined text-sm">chevron_right</span></Link>
           </div>
           <div className="flex overflow-x-auto no-scrollbar gap-5 snap-x -mx-5 px-5">
              {activeChallenges.map(challenge => (
                <div 
                  key={challenge.id} 
                  onClick={() => navigate(`/challenge-details/${challenge.id}`)}
                  className="flex-none w-60 snap-start bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-soft active:scale-95 transition-transform"
                >
                   <div className="h-32 bg-cover bg-center" style={{backgroundImage: `url("${challenge.imageUrl}")`}}>
                      <div className="w-full h-full bg-gradient-to-t from-black/50 to-transparent p-4 flex flex-col justify-end">
                         <span className="text-[10px] font-extrabold text-white bg-primary/80 backdrop-blur-md self-start px-2 py-0.5 rounded-md uppercase mb-1">STREAK {challenge.streak}D</span>
                         <h4 className="font-bold text-white truncate text-sm">{challenge.title}</h4>
                      </div>
                   </div>
                   <div className="p-4 space-y-3">
                      <div className="flex justify-between items-center text-[10px] font-bold text-black/40 uppercase">
                         <span>Progress</span>
                         <span className="text-primary">{challenge.progress}%</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                         <div className="bg-primary h-full rounded-full" style={{width: `${challenge.progress}%`}}></div>
                      </div>
                   </div>
                </div>
              ))}
              <button 
                onClick={() => navigate('/create-deal')}
                className="flex-none w-40 snap-start bg-white border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center gap-3 active:scale-95 transition-all text-black/40 group"
              >
                <div className="size-12 rounded-full border-2 border-dashed border-slate-200 flex items-center justify-center group-hover:border-primary group-hover:text-primary transition-colors">
                   <span className="material-symbols-outlined text-3xl">add</span>
                </div>
                <span className="text-xs font-bold">새 매칭 시작</span>
              </button>
           </div>
        </section>

        {/* Motivational Banner */}
        <section className="bg-primary-light rounded-3xl p-6 text-black shadow-soft relative overflow-hidden group">
           <div className="relative z-10">
              <h3 className="text-xl font-extrabold mb-1 text-black">상위 1%를 향한 도전</h3>
              <p className="text-xs text-black/70 font-medium leading-relaxed mb-4">현재까지 총 <span className="font-bold underline text-primary">12,500 코인</span>을<br />성공적으로 지켜내셨어요! 🎉</p>
              <button className="bg-primary text-white px-5 py-2 rounded-xl text-xs font-extrabold shadow-sm active:scale-95 transition-transform">리포트 확인</button>
           </div>
           <span className="absolute -bottom-6 -right-6 material-symbols-outlined text-[10rem] text-primary/5 select-none group-hover:scale-110 transition-transform duration-700">stars</span>
        </section>
      </main>

      <BottomNav />
    </div>
  );
};

export default Dashboard;
