
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Challenge } from '../types';

// Define the missing LockScreenProps interface
interface LockScreenProps {
  user: User;
  challenges: Challenge[];
}

const LockScreen: React.FC<LockScreenProps> = ({ user, challenges }) => {
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());
  const activeChallenges = challenges.filter(c => c.status === 'active');
  
  const totalProgress = activeChallenges.length > 0 
    ? Math.round(activeChallenges.reduce((acc, c) => acc + c.progress, 0) / activeChallenges.length)
    : 0;

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeString = currentTime.toLocaleTimeString('ko-KR', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });

  const dateString = currentTime.toLocaleDateString('ko-KR', {
    month: 'long',
    day: 'numeric',
    weekday: 'long'
  });

  return (
    <div className="fixed inset-0 z-[1000] bg-background-light text-black font-body animate-in fade-in duration-700 overflow-hidden">
      {/* Background Decor */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] size-96 rounded-full bg-primary blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] size-96 rounded-full bg-accent-blue blur-[120px]"></div>
      </div>

      <main className="relative z-10 h-full flex flex-col items-center justify-between p-10 py-20">
        {/* Time & Date Area */}
        <div className="text-center space-y-2 animate-in slide-in-from-top duration-1000">
          <p className="text-lg font-bold text-black/40 tracking-widest uppercase">{dateString}</p>
          <h1 className="text-8xl font-display font-black tracking-tight text-black drop-shadow-sm">{timeString}</h1>
        </div>

        {/* Goals & Progress Summary */}
        <div className="w-full max-w-sm space-y-6 animate-in fade-in zoom-in duration-1000 delay-300">
          <div className="bg-white/40 backdrop-blur-2xl rounded-[2.5rem] p-8 border border-black/5 shadow-floating">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-black/40">Today's Momentum</h3>
              <span className="bg-primary text-white text-[10px] font-black px-3 py-1 rounded-full">{totalProgress}% Done</span>
            </div>
            
            <div className="space-y-5">
              {activeChallenges.slice(0, 3).map(challenge => (
                <div key={challenge.id} className="space-y-2">
                  <div className="flex justify-between items-center px-1">
                    <span className="text-sm font-bold truncate pr-4 text-black">{challenge.title}</span>
                    <span className="text-[10px] font-black text-black/30">{challenge.progress}%</span>
                  </div>
                  <div className="w-full bg-black/5 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-primary h-full transition-all duration-1000" 
                      style={{ width: `${challenge.progress}%` }}
                    ></div>
                  </div>
                </div>
              ))}
              
              {activeChallenges.length === 0 && (
                <p className="text-center text-black/30 py-4 font-medium italic">진행 중인 매칭이 없습니다.</p>
              )}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-white/60 backdrop-blur-lg p-4 rounded-3xl border border-black/5 flex items-center gap-3">
                <span className="material-symbols-outlined text-accent-yellow fill-1">monetization_on</span>
                <div>
                   <p className="text-[10px] font-black text-black/30 uppercase">Safe Balance</p>
                   <p className="text-sm font-black text-black">{user.balance.toLocaleString()}</p>
                </div>
             </div>
             <div className="bg-white/60 backdrop-blur-lg p-4 rounded-3xl border border-black/5 flex items-center gap-3">
                <span className="material-symbols-outlined text-primary">local_fire_department</span>
                <div>
                   <p className="text-[10px] font-black text-black/30 uppercase">Total Streak</p>
                   <p className="text-sm font-black text-black">{challenges.reduce((a, b) => a + b.streak, 0)}D</p>
                </div>
             </div>
          </div>
        </div>

        {/* Swipe to Unlock / Tap to Back */}
        <button 
          onClick={() => navigate('/')}
          className="flex flex-col items-center gap-4 group animate-pulse"
        >
          <div className="size-12 rounded-full border border-black/10 flex items-center justify-center group-active:scale-90 transition-transform">
             <span className="material-symbols-outlined text-black/40">keyboard_double_arrow_up</span>
          </div>
          <p className="text-xs font-black uppercase tracking-[0.3em] text-black/30">Swipe up to momentum</p>
        </button>
      </main>
    </div>
  );
};

export default LockScreen;
