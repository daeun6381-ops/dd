
import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import { Post, PostComment } from '../types';
import { storage, PUBLIC_CHALLENGES } from '../services/storage';

const CommunityHub: React.FC = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('전체');
  
  // Comment Modal State
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [newComment, setNewComment] = useState('');
  const commentScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLoading(true);
    const storedPosts = storage.getPosts();
    setPosts(storedPosts);
    setLoading(false);
  }, []);

  const handleAddComment = () => {
    if (!selectedPost || !newComment.trim()) return;

    const user = storage.getUser();
    const comment: PostComment = {
      id: Date.now().toString(),
      author: user.name,
      authorAvatar: user.avatarUrl,
      content: newComment,
      timestamp: '방금 전'
    };

    const updatedPost = storage.addComment(selectedPost.id, comment);
    if (updatedPost) {
      setPosts(storage.getPosts());
      setSelectedPost(updatedPost);
      setNewComment('');
      setTimeout(() => {
        if (commentScrollRef.current) {
          commentScrollRef.current.scrollTop = commentScrollRef.current.scrollHeight;
        }
      }, 100);
    }
  };

  const categories = [
    { name: '전체', icon: 'apps' },
    { name: '스터디', icon: 'school' },
    { name: '운동', icon: 'fitness_center' },
    { name: '루틴', icon: 'psychology' },
    { name: '기타', icon: 'more_horiz' }
  ];

  return (
    <div className="pb-24 bg-background-light min-h-screen text-black font-body relative overflow-x-hidden">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 glass-header border-b border-black/5">
        <div className="flex items-center p-4 justify-between">
          <h2 className="text-2xl font-black tracking-tight text-black">매칭 허브</h2>
          <div className="flex gap-2">
            <button className="size-10 rounded-full bg-black/5 flex items-center justify-center text-black">
              <span className="material-symbols-outlined text-xl">search</span>
            </button>
            <button className="size-10 rounded-full bg-black/5 flex items-center justify-center text-black">
              <span className="material-symbols-outlined text-xl">notifications</span>
            </button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-2 p-4 pt-0 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button 
              key={cat.name}
              onClick={() => setActiveCategory(cat.name)}
              className={`flex h-9 shrink-0 items-center justify-center gap-x-2 rounded-full px-5 transition-all ${
                activeCategory === cat.name ? 'bg-primary text-white font-bold' : 'bg-black/5 text-black/40 font-medium'
              }`}
            >
              <span className="material-symbols-outlined text-sm">{cat.icon}</span>
              <p className="text-sm">{cat.name}</p>
            </button>
          ))}
        </div>
      </header>

      <main className="p-4 space-y-8">
        {/* Trending Challenges Section */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-black text-black flex items-center gap-2">
              <span className="material-symbols-outlined text-accent-yellow fill-1">local_fire_department</span>
              인기 매칭 챌린지
            </h2>
            <span className="text-xs text-black/30 font-bold uppercase tracking-widest">실시간</span>
          </div>
          <div className="flex overflow-x-auto no-scrollbar gap-4 snap-x">
            {PUBLIC_CHALLENGES.map(challenge => (
              <div 
                key={challenge.id} 
                onClick={() => navigate(`/challenge-details/${challenge.id}`)}
                className="flex-none w-72 rounded-2xl bg-white border border-black/5 overflow-hidden snap-start shadow-xl active:scale-95 transition-transform"
              >
                <div className="h-36 bg-cover bg-center relative" style={{backgroundImage: `url("${challenge.imageUrl}")`}}>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-3 left-3">
                    <span className="bg-primary/20 text-primary border border-primary/30 px-2 py-0.5 rounded text-[10px] font-bold uppercase mb-1 inline-block">
                      {challenge.type === 'Group' ? '그룹' : '개인'}
                    </span>
                    <h3 className="font-bold text-sm text-white">{challenge.title}</h3>
                  </div>
                  <div className="absolute top-3 right-3 bg-accent-yellow text-black px-2 py-1 rounded-lg text-[10px] font-black shadow-lg">
                    {challenge.deposit.toLocaleString()} COIN
                  </div>
                </div>
                <div className="p-3 flex items-center justify-between">
                  <div className="flex -space-x-2">
                    {[1,2,3].map(i => (
                      <div key={i} className="size-6 rounded-full border-2 border-white bg-slate-700 overflow-hidden">
                        <img src={`https://picsum.photos/seed/${challenge.id}${i}/50/50`} alt="user" />
                      </div>
                    ))}
                    <div className="size-6 rounded-full border-2 border-white bg-slate-100 flex items-center justify-center text-[8px] font-bold text-black/40">+12</div>
                  </div>
                  <p className="text-[10px] text-black/40 font-medium">현재 {Math.floor(Math.random() * 50) + 10}명 참여 중</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Community Feed Section */}
        <section className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-black text-black">챌린지 실시간 피드</h2>
            <button className="text-primary text-xs font-bold">최신순</button>
          </div>
          
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-48 w-full bg-black/5 rounded-2xl animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map(post => (
                <div key={post.id} className="bg-white rounded-2xl border border-black/5 overflow-hidden shadow-sm hover:border-black/10 transition-colors">
                  <div className="p-4 flex items-center gap-3">
                    <div className="size-10 rounded-full bg-slate-100 overflow-hidden border border-black/10">
                      <img src={post.authorAvatar} alt={post.author} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-black">{post.author}</p>
                      <p className="text-[10px] text-black/40 font-medium">{post.timestamp} • <span className="text-primary">{post.tag}</span></p>
                    </div>
                    <button className="size-8 flex items-center justify-center text-black/20">
                      <span className="material-symbols-outlined">more_vert</span>
                    </button>
                  </div>
                  <div className="px-4 pb-4">
                    <p className="text-sm text-black/70 leading-relaxed mb-4">
                      {post.content}
                    </p>
                    {/* Mock Post Image */}
                    <div className="aspect-video w-full rounded-xl bg-slate-100 overflow-hidden mb-4 relative">
                       <img src={`https://picsum.photos/seed/${post.id}/600/337`} className="w-full h-full object-cover opacity-90" alt="post content" />
                       <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded-md flex items-center gap-1">
                          <span className="material-symbols-outlined text-[12px] text-primary">verified</span>
                          <span className="text-[10px] text-white font-bold">인증 완료</span>
                       </div>
                    </div>
                    <div className="flex items-center gap-6 text-black/30">
                      <button className="flex items-center gap-1.5 text-xs font-bold hover:text-primary transition-colors">
                        <span className="material-symbols-outlined text-lg">favorite</span>
                        {post.likes}
                      </button>
                      <button 
                        onClick={() => setSelectedPost(post)}
                        className="flex items-center gap-1.5 text-xs font-bold hover:text-primary transition-colors"
                      >
                        <span className="material-symbols-outlined text-lg">chat_bubble</span>
                        {post.comments}
                      </button>
                      <button className="ml-auto flex items-center gap-1.5 text-xs font-bold hover:text-primary transition-colors">
                        <span className="material-symbols-outlined text-lg">share</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Comment Bottom Sheet Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="w-full max-w-md h-[80vh] bg-white rounded-t-3xl border-t border-black/10 shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-500">
            {/* Modal Header */}
            <div className="p-4 flex items-center justify-between border-b border-black/5">
              <h3 className="font-black text-black">댓글 {selectedPost.comments}</h3>
              <button 
                onClick={() => setSelectedPost(null)}
                className="size-10 rounded-full bg-black/5 flex items-center justify-center text-black"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {/* Comments List */}
            <div 
              ref={commentScrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar"
            >
              {selectedPost.commentsList && selectedPost.commentsList.length > 0 ? (
                selectedPost.commentsList.map(comment => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="size-8 rounded-full bg-slate-100 overflow-hidden shrink-0">
                      <img src={comment.authorAvatar} alt={comment.author} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-black">{comment.author}</span>
                        <span className="text-[10px] text-black/40">{comment.timestamp}</span>
                      </div>
                      <p className="text-sm text-black/70 leading-relaxed bg-black/5 px-3 py-2 rounded-2xl rounded-tl-none">
                        {comment.content}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-black/20 space-y-2">
                  <span className="material-symbols-outlined text-5xl">chat_bubble_outline</span>
                  <p className="text-sm font-medium">첫 번째 댓글을 남겨보세요!</p>
                </div>
              )}
            </div>

            {/* Comment Input Area */}
            <div className="p-4 bg-white border-t border-black/5">
              <div className="flex items-center gap-3">
                <div className="size-8 rounded-full overflow-hidden shrink-0 border border-black/10">
                  <img src={storage.getUser().avatarUrl} alt="my profile" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 relative flex items-center">
                  <input 
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                    placeholder="댓글을 입력하세요..."
                    className="w-full bg-black/5 border-black/10 rounded-full h-10 pl-4 pr-10 text-sm focus:ring-primary focus:border-primary transition-all text-black"
                  />
                  <button 
                    onClick={handleAddComment}
                    disabled={!newComment.trim()}
                    className="absolute right-1 size-8 rounded-full bg-primary text-white flex items-center justify-center disabled:opacity-50 active:scale-90 transition-transform"
                  >
                    <span className="material-symbols-outlined text-sm font-bold">arrow_upward</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
};

export default CommunityHub;
