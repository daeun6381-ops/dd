
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Challenge, Proof } from '../types';
import { storage, PUBLIC_CHALLENGES, getMockParticipants } from '../services/storage';

interface ChallengeDetailsProps {
  challenges: Challenge[];
}

const ChallengeDetails: React.FC<ChallengeDetailsProps> = ({ challenges }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const myChallenge = challenges.find(c => c.id === id);
  const publicChallenge = PUBLIC_CHALLENGES.find(c => c.id === id);
  const challenge = myChallenge || publicChallenge;

  const [myProof, setMyProof] = useState<Proof | null>(null);
  const [isMatching, setIsMatching] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const [matchingProgress, setMatchingProgress] = useState(0);

  useEffect(() => {
    if (challenge) {
      const allProofs = storage.getProofs();
      const latest = allProofs.filter(p => p.challengeId === challenge.id).pop();
      if (latest) setMyProof(latest);
    }
  }, [challenge]);

  if (!challenge) {
    return (
      <div className="flex flex-col items-center justify-center h-screen p-8 text-center bg-background-light font-body">
        <span className="material-symbols-outlined text-6xl text-slate-200 mb-4">search_off</span>
        <p className="text-slate-500 font-bold text-lg">해당 정보를 찾을 수 없어요.</p>
        <button onClick={() => navigate('/')} className="mt-8 bg-primary text-white px-8 py-3 rounded-2xl font-bold shadow-soft">홈으로 돌아가기</button>
      </div>
    );
  }

  const handleFinalJoin = () => {
    setShowRules(false);
    setIsMatching(true);
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      if (progress >= 100) {
        setMatchingProgress(100);
        clearInterval(interval);
        setTimeout(() => {
          try {
            storage.joinChallenge(challenge);
            navigate('/');
          } catch (err: any) {
            alert(err.message);
            setIsMatching(false);
          }
        }, 1000);
      } else {
        setMatchingProgress(progress);
      }
    }, 150);
  };

  const participants = getMockParticipants(challenge.id);
  const user = storage.getUser();

  if (isMatching) {
    return (
      <div className="fixed inset-0 z-[200] bg-primary flex flex-col items-center justify-center text-white p-8 overflow-hidden">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="coin-particle" style={{ left: `${Math.random()*100}%`, animationDelay: `${Math.random()}s`, color: '#FFD60A' }}>
            <span className="material-symbols-outlined text-3xl fill-1">monetization_on</span>
          </div>
        ))}
        <div className="text-center space-y-6 relative z-10">
          <div className="size-24 rounded-full bg-white/20 backdrop-blur-md border-2 border-white/30 flex items-center justify-center mx-auto vault-active">
             <span className="material-symbols-outlined text-5xl">handshake</span>
          </div>
          <h2 className="text-3xl font-black">{challenge.title}<br />매칭 계약 체결 중</h2>
          <div className="w-full bg-white/20 h-1.5 rounded-full overflow-hidden max-w-[200px] mx-auto">
             <div className="bg-white h-full transition-all duration-300" style={{width: `${matchingProgress}%`}}></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-40 font-body min-h-screen bg-background-light animate-in fade-in duration-500">
      <nav className="sticky top-0 z-50 glass-header px-4 py-4 flex items-center justify-between border-b border-slate-100">
        <button onClick={() => navigate('/')} className="flex items-center justify-center size-10 rounded-full bg-slate-50 border border-slate-100 active:scale-90 transition-all">
          <span className="material-symbols-outlined text-slate-700 font-bold">chevron_left</span>
        </button>
        <div className="text-center flex-1 px-4">
          <h1 className="text-sm font-extrabold text-slate-800 truncate">{challenge.title}</h1>
          <p className="text-[10px] text-primary font-black uppercase tracking-widest">실시간 매칭 보드</p>
        </div>
        <div className="size-10"></div>
      </nav>

      <main className="space-y-10">
        {/* Banner */}
        <div className="h-60 w-full bg-cover bg-center relative" style={{backgroundImage: `url("${challenge.imageUrl}")`}}>
           <div className="absolute inset-0 bg-gradient-to-t from-background-light via-transparent to-transparent"></div>
           <div className="absolute bottom-6 left-6 right-6">
              <h2 className="text-2xl font-black text-slate-900">{challenge.title}</h2>
              <div className="flex gap-2 mt-2">
                 <span className="bg-primary/10 text-primary text-[9px] font-black px-2 py-0.5 rounded-md border border-primary/20">{(challenge.deposit).toLocaleString()} COIN STAKED</span>
                 <span className="bg-slate-100 text-slate-500 text-[9px] font-black px-2 py-0.5 rounded-md border border-slate-200">{challenge.durationDays} DAYS</span>
              </div>
           </div>
        </div>

        {/* Real-time Matching Board */}
        <section className="px-6 space-y-6">
           <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-800">가디언즈 인증 보드</h3>
                <p className="text-[11px] text-slate-400 font-medium">오늘의 성공과 실패를 실시간으로 확인하세요</p>
              </div>
              <div className="text-right">
                 <p className="text-[10px] font-black text-slate-300 uppercase">Live Update</p>
                 <span className="text-xs font-black text-primary">82% Success</span>
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              {/* My Profile Card */}
              <div className={`bg-white rounded-[2rem] p-4 border transition-all shadow-soft overflow-hidden relative ${myProof ? 'border-primary/30 ring-2 ring-primary/5' : 'border-slate-100'}`}>
                 <div className="flex items-center gap-3 mb-3">
                    <img src={user.avatarUrl} className="size-8 rounded-full border border-slate-100" alt="me" />
                    <div className="flex-1 min-w-0">
                       <p className="text-[10px] font-black text-slate-800 truncate">나 (김철수)</p>
                       <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase ${myProof ? 'bg-primary text-white' : 'bg-danger text-white'}`}>
                          {myProof ? 'Success' : 'Fail'}
                       </span>
                    </div>
                 </div>
                 <div className="aspect-square rounded-2xl bg-slate-50 overflow-hidden relative">
                    {myProof ? (
                       <img src={myProof.imageUrl} className="w-full h-full object-cover" alt="my proof" />
                    ) : (
                       <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 opacity-60">
                          <span className="material-symbols-outlined text-slate-300 text-3xl">photo_camera_off</span>
                          <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase">No Proof Yet</p>
                       </div>
                    )}
                    {myProof && <div className="absolute top-2 right-2 size-5 bg-primary text-white rounded-full flex items-center justify-center shadow-lg"><span className="material-symbols-outlined text-[14px] font-black">check</span></div>}
                 </div>
              </div>

              {/* Other Participants Cards */}
              {participants.map(p => (
                <div key={p.id} className={`bg-white rounded-[2rem] p-4 border border-slate-100 shadow-soft overflow-hidden relative ${p.status === 'fail' ? 'grayscale opacity-70 bg-slate-50/50' : ''}`}>
                   <div className="flex items-center gap-3 mb-3">
                      <img src={p.avatar} className="size-8 rounded-full border border-slate-200" alt={p.name} />
                      <div className="flex-1 min-w-0">
                         <p className="text-[10px] font-black text-slate-800 truncate">{p.name}</p>
                         <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase ${p.status === 'success' ? 'bg-primary text-white' : 'bg-danger text-white'}`}>
                            {p.status.toUpperCase()}
                         </span>
                      </div>
                   </div>
                   <div className="aspect-square rounded-2xl bg-slate-100 overflow-hidden relative">
                      {p.status === 'success' ? (
                         <img src={p.proofImg!} className="w-full h-full object-cover" alt="proof" />
                      ) : (
                         <div className="w-full h-full flex flex-col items-center justify-center">
                            <span className="material-symbols-outlined text-slate-300 text-3xl">block</span>
                            <p className="text-[9px] font-black text-slate-400 mt-1 uppercase">Staking Lost</p>
                         </div>
                      )}
                      {p.status === 'success' && <div className="absolute top-2 right-2 size-5 bg-primary text-white rounded-full flex items-center justify-center shadow-lg"><span className="material-symbols-outlined text-[14px] font-black">check</span></div>}
                   </div>
                </div>
              ))}
           </div>
        </section>

        {/* Incentive Section */}
        <section className="px-6 pb-12">
           <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
              <div className="relative z-10">
                 <h4 className="text-xl font-black mb-2">실패한 코인은 어디로?</h4>
                 <p className="text-sm text-white/70 leading-relaxed font-medium">오늘 인증에 실패한 2명의 코인은 내일 성공한 수호자들에게 리워드로 공평하게 배분됩니다. 끝까지 코인을 지키세요!</p>
              </div>
              <span className="absolute -bottom-10 -right-10 material-symbols-outlined text-[10rem] text-white/5 font-black">currency_exchange</span>
           </div>
        </section>
      </main>

      {/* Persistent Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background-light via-background-light to-transparent z-40">
        <div className="max-w-md mx-auto">
          {!!myChallenge ? (
            <button 
              onClick={() => navigate('/upload-proof')} 
              className="w-full bg-primary text-white py-5 rounded-[2rem] font-black text-lg shadow-floating flex items-center justify-center gap-3 active:scale-[0.98] transition-all"
            >
              <span className="material-symbols-outlined font-black">photo_camera</span>
              {myProof ? '인증 수정하기' : '오늘의 인증 완료하기'}
            </button>
          ) : (
            <button 
              onClick={() => setShowRules(true)}
              className="w-full bg-slate-900 text-white py-5 rounded-[2rem] font-black text-lg shadow-floating flex items-center justify-center gap-3 active:scale-[0.98] transition-all"
            >
              <span className="material-symbols-outlined font-black">bolt</span> 
              매칭 참여하고 코인 걸기
            </button>
          )}
        </div>
      </div>

      {showRules && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="w-full max-w-md bg-white rounded-t-[2.5rem] p-8 shadow-floating animate-in slide-in-from-bottom duration-500">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h2 className="text-2xl font-black text-slate-900 mb-1">Staking Rules</h2>
                <p className="text-sm text-slate-400 font-medium">당신의 자산을 지키기 위한 약속</p>
              </div>
              <button onClick={() => setShowRules(false)} className="size-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="space-y-6 mb-10">
               <div className="flex gap-4">
                  <div className="size-12 rounded-2xl bg-primary-light flex shrink-0 items-center justify-center text-primary">
                    <span className="material-symbols-outlined">group</span>
                  </div>
                  <div>
                     <h4 className="font-extrabold text-slate-800 text-sm">상호 감시 시스템</h4>
                     <p className="text-xs text-slate-400 leading-normal mt-0.5">서로의 인증 사진을 실시간으로 확인하고 평가할 수 있습니다.</p>
                  </div>
               </div>
               <div className="flex gap-4">
                  <div className="size-12 rounded-2xl bg-red-50 flex shrink-0 items-center justify-center text-danger">
                    <span className="material-symbols-outlined">warning</span>
                  </div>
                  <div>
                     <h4 className="font-extrabold text-slate-800 text-sm">벌금 자동 징수</h4>
                     <p className="text-xs text-slate-400 leading-normal mt-0.5">인증 누락 시 코인은 예외 없이 즉시 몰수되어 리워드 풀로 이동합니다.</p>
                  </div>
               </div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowRules(false)} className="flex-1 bg-slate-50 text-slate-400 py-4 rounded-2xl font-bold">닫기</button>
              <button onClick={handleFinalJoin} className="flex-[2] bg-primary text-white py-4 rounded-2xl font-black shadow-soft">동의하고 시작하기</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChallengeDetails;
