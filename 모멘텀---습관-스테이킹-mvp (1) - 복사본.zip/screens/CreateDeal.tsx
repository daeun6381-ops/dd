
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storage';
import { Challenge } from '../types';

interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  recommendations: string[];
}

const CATEGORIES: Category[] = [
  { id: 'exercise', name: '운동', icon: 'fitness_center', color: '#22c3a8', recommendations: ['매일 스쿼트 100개', '조깅 30분 하기', '플랭크 3분'] },
  { id: 'study', name: '학습', icon: 'school', color: '#007AFF', recommendations: ['영단어 30개 외우기', '코딩 문제 1개 풀기', '경제 뉴스 읽기'] },
  { id: 'habit', name: '생활습관', icon: 'wb_sunny', color: '#FFD60A', recommendations: ['아침 7시 기상', '물 2L 마시기', '영양제 챙겨먹기'] },
  { id: 'reading', name: '독서', icon: 'menu_book', color: '#A259FF', recommendations: ['책 20페이지 읽기', '독서 기록 남기기', '신문 사설 읽기'] },
];

interface CreateDealProps {
  onCreated: () => void;
}

const CreateDeal: React.FC<CreateDealProps> = ({ onCreated }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState<'category' | 'details' | 'matching'>('category');
  const [selectedCat, setSelectedCat] = useState<Category | null>(null);
  const [title, setTitle] = useState('');
  const [deposit, setDeposit] = useState(10000);
  const [days, setDays] = useState(21);
  const [matchingProgress, setMatchingProgress] = useState(0);

  const handleCategorySelect = (cat: Category) => {
    setSelectedCat(cat);
    setTitle(cat.recommendations[0]);
    setStep('details');
  };

  const startMatching = () => {
    if (!title) return alert('목표를 입력해주세요.');
    setStep('matching');
    
    // 매칭 애니메이션 시뮬레이션
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 15;
      if (progress >= 100) {
        setMatchingProgress(100);
        clearInterval(interval);
        setTimeout(finalizeChallenge, 1200);
      } else {
        setMatchingProgress(progress);
      }
    }, 200);
  };

  const finalizeChallenge = () => {
    const newChallenge: Challenge = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      type: 'Personal',
      durationDays: days,
      deposit: deposit,
      startDate: new Date().toISOString(),
      progress: 0,
      streak: 0,
      imageUrl: `https://images.unsplash.com/photo-${selectedCat?.id === 'exercise' ? '1517836357463-d25dfeac3438' : '1434030216411-0b793f4b4173'}?auto=format&fit=crop&q=80&w=600`,
      status: 'active'
    };

    try {
      storage.joinChallenge(newChallenge);
      onCreated();
      navigate('/');
    } catch (err: any) {
      alert(err.message);
      setStep('details');
    }
  };

  if (step === 'category') {
    return (
      <div className="fixed inset-0 z-[100] bg-background-light flex flex-col animate-in fade-in slide-in-from-bottom duration-500">
        <header className="p-6 flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="size-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
            <span className="material-symbols-outlined font-bold">close</span>
          </button>
          <div className="flex gap-1.5">
             <div className="w-8 h-1.5 rounded-full bg-primary"></div>
             <div className="w-8 h-1.5 rounded-full bg-slate-200"></div>
          </div>
          <div className="size-10"></div>
        </header>
        
        <main className="flex-1 px-8 py-4 overflow-y-auto no-scrollbar">
          <h2 className="text-3xl font-black mb-2 text-slate-900 tracking-tight">어떤 자산을<br /><span className="text-primary">빌드업</span> 할까요?</h2>
          <p className="text-slate-400 mb-10 text-sm font-medium">시작하고 싶은 카테고리를 선택하세요.</p>
          
          <div className="grid grid-cols-2 gap-4">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategorySelect(cat)}
                className="group flex flex-col items-start p-6 rounded-[2.5rem] bg-white border border-slate-100 shadow-soft hover:border-primary/50 transition-all active:scale-95 text-left overflow-hidden relative"
              >
                <div className="size-12 rounded-2xl flex items-center justify-center mb-4 transition-colors" style={{backgroundColor: `${cat.color}15`}}>
                  <span className="material-symbols-outlined text-2xl font-bold" style={{color: cat.color}}>{cat.icon}</span>
                </div>
                <h3 className="text-lg font-extrabold text-slate-800">{cat.name}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Ready to match</p>
              </button>
            ))}
          </div>
        </main>
      </div>
    );
  }

  if (step === 'matching') {
    return (
      <div className="fixed inset-0 z-[200] bg-primary flex flex-col items-center justify-center text-white overflow-hidden">
        {/* Coin Particles */}
        {Array.from({ length: 15 }).map((_, i) => (
          <div 
            key={i} 
            className="coin-particle" 
            style={{ 
              left: `${Math.random() * 100}%`, 
              animationDelay: `${Math.random() * 2}s`,
              color: '#FFD60A'
            }}
          >
            <span className="material-symbols-outlined text-4xl fill-1">monetization_on</span>
          </div>
        ))}

        <div className="relative z-10 text-center space-y-8 px-8">
           <div className="size-32 rounded-full bg-white/20 backdrop-blur-xl flex items-center justify-center mx-auto vault-active border-4 border-white/30">
              <span className="material-symbols-outlined text-6xl">account_balance</span>
           </div>
           
           <div className="space-y-2">
              <h2 className="text-3xl font-black tracking-tight">
                {matchingProgress < 100 ? '코인 수호 매칭 중...' : '매칭 계약 완료!'}
              </h2>
              <p className="text-white/70 font-medium">
                {matchingProgress < 100 ? '다른 1,245명의 참가자들과 자산을 연결하고 있습니다.' : '이제 당신의 약속은 안전하게 예치되었습니다.'}
              </p>
           </div>

           <div className="w-full bg-white/20 rounded-full h-2 max-w-xs mx-auto overflow-hidden">
              <div 
                className="bg-white h-full transition-all duration-300" 
                style={{ width: `${matchingProgress}%` }}
              ></div>
           </div>
           
           <div className="flex justify-center gap-4">
              {[1,2,3,4].map(i => (
                <div key={i} className="size-10 rounded-full border-2 border-white/30 overflow-hidden animate-pulse" style={{animationDelay: `${i * 0.2}s`}}>
                   <img src={`https://picsum.photos/seed/m${i}/100/100`} alt="matcher" />
                </div>
              ))}
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background-light text-slate-900 font-body animate-in fade-in duration-300">
      <header className="sticky top-0 z-50 glass-header border-b border-slate-100 p-5 flex items-center justify-between">
        <button onClick={() => setStep('category')} className="size-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
          <span className="material-symbols-outlined font-bold">arrow_back</span>
        </button>
        <h1 className="font-extrabold text-sm uppercase tracking-widest text-slate-400">Contract Setup</h1>
        <div className="size-10"></div>
      </header>

      <main className="p-6 space-y-10 pb-36">
        {/* Detail Input */}
        <section className="space-y-4">
          <div className="flex items-center gap-3">
             <div className="size-10 rounded-xl flex items-center justify-center" style={{backgroundColor: `${selectedCat?.color}15`}}>
                <span className="material-symbols-outlined font-bold" style={{color: selectedCat?.color}}>{selectedCat?.icon}</span>
             </div>
             <h2 className="text-xl font-extrabold text-slate-800">{selectedCat?.name} 목표 설정</h2>
          </div>
          
          <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-soft">
            <label className="block space-y-3">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">What's your goal?</span>
              <input 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-50 border-none rounded-2xl h-14 px-5 font-bold text-lg focus:ring-2 focus:ring-primary transition-all text-slate-800"
                placeholder="목표를 직접 입력해보세요"
              />
            </label>
            <div className="flex flex-wrap gap-2 mt-5">
              {selectedCat?.recommendations.map(rec => (
                <button 
                  key={rec}
                  onClick={() => setTitle(rec)}
                  className={`text-[11px] px-4 py-2 rounded-full border transition-all font-bold ${
                    title === rec ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20' : 'bg-slate-50 border-slate-100 text-slate-400'
                  }`}
                >
                  {rec}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Tactile Staking Section */}
        <section className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2 px-1">
            <span className="material-symbols-outlined text-primary text-lg">monetization_on</span>
            Money Matching
          </h3>
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-soft text-center space-y-6">
             <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">예치할 코인 자산</span>
                <div className="flex items-center justify-center gap-2">
                   <span className="text-4xl font-black text-slate-900 tracking-tighter">{(deposit).toLocaleString()}</span>
                   <span className="text-sm font-black text-primary uppercase">Coin</span>
                </div>
             </div>
             
             <div className="relative py-4">
                <input 
                  type="range" min="1000" max="100000" step="5000"
                  value={deposit}
                  onChange={(e) => setDeposit(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-full appearance-none cursor-pointer accent-primary"
                />
                <div className="flex justify-between mt-4 px-1 text-[10px] font-black text-slate-300">
                   <span>1K</span>
                   <span>50K</span>
                   <span>100K</span>
                </div>
             </div>

             <div className="bg-primary-light p-4 rounded-2xl flex items-center gap-3">
                <span className="material-symbols-outlined text-primary text-xl">shield_person</span>
                <p className="text-[11px] text-primary font-bold text-left leading-snug">
                  인증 실패 시 매칭된 코인은<br />다른 수호자들에게 리워드로 분배됩니다.
                </p>
             </div>
          </div>
        </section>

        {/* Duration Selection */}
        <section className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Duration</h3>
          <div className="flex gap-3">
            {[7, 14, 21, 30].map(d => (
              <button 
                key={d}
                onClick={() => setDays(d)}
                className={`flex-1 py-4 rounded-2xl font-black text-xs transition-all ${
                  days === d ? 'bg-slate-900 text-white shadow-xl' : 'bg-white text-slate-400 border border-slate-100'
                }`}
              >
                {d}일
              </button>
            ))}
          </div>
        </section>
      </main>

      {/* Floating Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background-light via-background-light to-transparent z-50">
        <button 
          onClick={startMatching}
          className="w-full bg-primary text-white font-black text-lg py-5 rounded-[2rem] shadow-floating hover:translate-y-[-2px] active:scale-95 transition-all flex items-center justify-center gap-3"
        >
          매칭 확정 및 시작
          <span className="material-symbols-outlined font-black">bolt</span>
        </button>
      </div>
    </div>
  );
};

export default CreateDeal;
