
import React from 'react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import { User, Challenge } from '../types';

interface ProfileProps {
  user: User;
  challenges: Challenge[];
}

const Profile: React.FC<ProfileProps> = ({ user, challenges }) => {
  const navigate = useNavigate();
  const completedCount = challenges.filter(c => c.status === 'completed').length;
  const activeCount = challenges.filter(c => c.status === 'active').length;
  const totalStreak = challenges.reduce((acc, curr) => acc + curr.streak, 0);

  return (
    <div className="pb-24 bg-background-light min-h-screen text-black font-body">
      <header className="px-6 pt-12 pb-8 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="flex flex-col items-center">
          <div className="relative mb-4">
            <div className="size-24 rounded-full border-4 border-primary/30 p-1">
              <img 
                src={user.avatarUrl} 
                alt="Profile" 
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            <button className="absolute bottom-0 right-0 size-8 bg-primary rounded-full flex items-center justify-center border-4 border-white text-white">
              <span className="material-symbols-outlined text-sm font-bold">edit</span>
            </button>
          </div>
          <h2 className="text-2xl font-black text-black">{user.name}</h2>
          <p className="text-black/40 text-sm font-medium">코인으로 성장하는 프로 습관러</p>
        </div>
      </header>

      <main className="px-6 space-y-8">
        {/* Stats Grid */}
        <section className="grid grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-black/5 text-center shadow-soft">
            <p className="text-[10px] font-bold text-black/30 uppercase mb-1">진행중</p>
            <p className="text-xl font-black text-primary">{activeCount}</p>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-black/5 text-center shadow-soft">
            <p className="text-[10px] font-bold text-black/30 uppercase mb-1">성공</p>
            <p className="text-xl font-black text-accent-yellow">{completedCount}</p>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-black/5 text-center shadow-soft">
            <p className="text-[10px] font-bold text-black/30 uppercase mb-1">총 스트릭</p>
            <p className="text-xl font-black text-black">{totalStreak}</p>
          </div>
        </section>

        {/* Wallet Section */}
        <section className="bg-white rounded-2xl p-6 border border-black/5 shadow-floating">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-accent-yellow fill-1">account_balance_wallet</span>
              <h3 className="font-black text-black">내 지갑</h3>
            </div>
            <span className="text-xs text-black/30 font-bold uppercase">매칭 가능 잔액</span>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <p className="text-3xl font-black text-black">{user.balance.toLocaleString()}<span className="text-sm font-medium text-black/30 ml-1">코인</span></p>
            </div>
            <button className="bg-primary text-white px-5 py-2.5 rounded-xl text-sm font-black active:scale-95 transition-transform shadow-lg shadow-primary/20">
              충전하기
            </button>
          </div>
        </section>

        {/* Settings List */}
        <section className="space-y-2">
          <h3 className="text-xs font-black text-black/30 uppercase tracking-[0.2em] px-1 mb-4">환경 설정</h3>
          <div className="bg-white rounded-2xl border border-black/5 overflow-hidden shadow-soft">
            <button className="w-full flex items-center gap-4 px-5 py-4 border-b border-black/5 active:bg-slate-50 transition-colors">
              <span className="material-symbols-outlined text-black/40">notifications</span>
              <span className="flex-1 text-left text-sm font-bold text-black">알림 설정</span>
              <span className="material-symbols-outlined text-black/10">chevron_right</span>
            </button>
            <button className="w-full flex items-center gap-4 px-5 py-4 border-b border-black/5 active:bg-slate-50 transition-colors">
              <span className="material-symbols-outlined text-black/40">security</span>
              <span className="flex-1 text-left text-sm font-bold text-black">계정 및 보안</span>
              <span className="material-symbols-outlined text-black/10">chevron_right</span>
            </button>
            <button className="w-full flex items-center gap-4 px-5 py-4 border-b border-black/5 active:bg-slate-50 transition-colors">
              <span className="material-symbols-outlined text-black/40">help_outline</span>
              <span className="flex-1 text-left text-sm font-bold text-black">고객 센터</span>
              <span className="material-symbols-outlined text-black/10">chevron_right</span>
            </button>
            <button className="w-full flex items-center gap-4 px-5 py-4 text-danger active:bg-red-50 transition-colors">
              <span className="material-symbols-outlined">logout</span>
              <span className="flex-1 text-left text-sm font-black">로그아웃</span>
            </button>
          </div>
        </section>

        <section className="pb-12 text-center">
          <p className="text-[10px] text-black/20 uppercase font-black tracking-widest">Version 1.0.2 MVP</p>
        </section>
      </main>

      <BottomNav />
    </div>
  );
};

export default Profile;
