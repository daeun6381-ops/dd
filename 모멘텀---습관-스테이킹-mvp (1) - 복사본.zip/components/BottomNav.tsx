
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const activeClass = "text-primary";
  const inactiveClass = "text-slate-300";

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/90 backdrop-blur-xl border-t border-slate-100 px-6 py-4 flex justify-between items-center z-50 rounded-t-3xl shadow-floating">
      <Link to="/" className={`flex flex-col items-center gap-1.5 transition-all active:scale-90 ${isActive('/') ? activeClass : inactiveClass}`}>
        <span className={`material-symbols-outlined text-2xl ${isActive('/') ? 'fill-1' : ''}`}>home</span>
        <span className="text-[10px] font-extrabold tracking-tight">홈</span>
      </Link>
      <Link to="/community" className={`flex flex-col items-center gap-1.5 transition-all active:scale-90 ${isActive('/community') ? activeClass : inactiveClass}`}>
        <span className={`material-symbols-outlined text-2xl ${isActive('/community') ? 'fill-1' : ''}`}>explore</span>
        <span className="text-[10px] font-extrabold tracking-tight">탐색</span>
      </Link>
      
      <div className="relative -top-10 mx-2">
        <button 
          onClick={() => navigate('/create-deal')} 
          className="size-14 bg-primary rounded-full flex items-center justify-center shadow-floating border-4 border-background-light hover:scale-110 active:scale-95 transition-all"
        >
          <span className="material-symbols-outlined text-white text-3xl font-bold">add</span>
        </button>
      </div>

      <Link to="/ranking" className={`flex flex-col items-center gap-1.5 transition-all active:scale-90 ${isActive('/ranking') ? activeClass : inactiveClass}`}>
        <span className={`material-symbols-outlined text-2xl ${isActive('/ranking') ? 'fill-1' : ''}`}>leaderboard</span>
        <span className="text-[10px] font-extrabold tracking-tight">랭킹</span>
      </Link>
      <Link to="/profile" className={`flex flex-col items-center gap-1.5 transition-all active:scale-90 ${isActive('/profile') ? activeClass : inactiveClass}`}>
        <span className={`material-symbols-outlined text-2xl ${isActive('/profile') ? 'fill-1' : ''}`}>person</span>
        <span className="text-[10px] font-extrabold tracking-tight">마이</span>
      </Link>
    </nav>
  );
};

export default BottomNav;
