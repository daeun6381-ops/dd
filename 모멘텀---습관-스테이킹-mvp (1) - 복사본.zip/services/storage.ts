
import { Challenge, User, Proof, ChatMessage, Post, PostComment } from '../types';

const STORAGE_KEYS = {
  USER: 'momentum_user',
  CHALLENGES: 'momentum_challenges',
  PROOFS: 'momentum_proofs',
  CHATS: 'momentum_chats',
  POSTS: 'momentum_posts',
};

export const PUBLIC_CHALLENGES: Challenge[] = [
  {
    id: 'trend_1',
    title: '기말고사 벼락치기 스프린트',
    type: 'Group',
    durationDays: 14,
    deposit: 3000,
    startDate: new Date().toISOString(),
    progress: 0,
    streak: 0,
    imageUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600',
    status: 'active'
  },
  {
    id: 'trend_2',
    title: '마라톤 완주 트레이닝',
    type: 'Group',
    durationDays: 60,
    deposit: 10000,
    startDate: new Date().toISOString(),
    progress: 0,
    streak: 0,
    imageUrl: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&q=80&w=600',
    status: 'active'
  }
];

export const getRankings = () => [
  { id: 'r1', name: '스테이킹킹', avatar: 'https://picsum.photos/seed/r1/100/100', score: 1250000, streak: 45, change: 'up' },
  { id: 'r2', name: '루틴마스터', avatar: 'https://picsum.photos/seed/r2/100/100', score: 980000, streak: 32, change: 'none' },
  { id: 'r3', name: '자산수호자', avatar: 'https://picsum.photos/seed/r3/100/100', score: 850000, streak: 28, change: 'down' },
  { id: 'r4', name: '코인수집가', avatar: 'https://picsum.photos/seed/r4/100/100', score: 620000, streak: 15, change: 'up' },
  { id: 'r5', name: '갓생살기', avatar: 'https://picsum.photos/seed/r5/100/100', score: 430000, streak: 12, change: 'none' },
  { id: 'r6', name: '챌린지중독', avatar: 'https://picsum.photos/seed/r6/100/100', score: 380000, streak: 9, change: 'down' },
  { id: 'r7', name: '열정맨', avatar: 'https://picsum.photos/seed/r7/100/100', score: 250000, streak: 7, change: 'up' },
];

export const getMockParticipants = (challengeId: string) => [
  { id: 'm1', name: '열공러_A', avatar: 'https://picsum.photos/seed/u1/100/100', status: 'success', proofImg: 'https://picsum.photos/seed/p1/300/300' },
  { id: 'm2', name: '밤샘장인', avatar: 'https://picsum.photos/seed/u2/100/100', status: 'fail', proofImg: null },
  { id: 'm3', name: 'A플러스가즈아', avatar: 'https://picsum.photos/seed/u3/100/100', status: 'success', proofImg: 'https://picsum.photos/seed/p3/300/300' },
  { id: 'm4', name: '커피중독자', avatar: 'https://picsum.photos/seed/u4/100/100', status: 'fail', proofImg: null },
  { id: 'm5', name: '도서관지기', avatar: 'https://picsum.photos/seed/u5/100/100', status: 'success', proofImg: 'https://picsum.photos/seed/p5/300/300' },
];

export const storage = {
  getUser: (): User => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    if (data) return JSON.parse(data);
    const defaultUser: User = {
      name: '나도현',
      balance: 50000,
      avatarUrl: 'https://picsum.photos/seed/alex/200/200'
    };
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(defaultUser));
    return defaultUser;
  },

  setUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },

  getChallenges: (): Challenge[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHALLENGES);
    if (data) return JSON.parse(data);
    
    const defaultChallenges: Challenge[] = [
      {
        id: '1',
        title: '30일 코딩 스프린트',
        type: 'Group',
        durationDays: 30,
        deposit: 5000,
        startDate: new Date().toISOString(),
        progress: 65,
        streak: 5,
        imageUrl: 'https://picsum.photos/seed/code/600/400',
        status: 'active'
      }
    ];
    localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(defaultChallenges));
    return defaultChallenges;
  },

  saveChallenges: (challenges: Challenge[]) => {
    localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(challenges));
  },

  joinChallenge: (challenge: Challenge) => {
    const user = storage.getUser();
    if (user.balance < challenge.deposit) {
      throw new Error('보유 코인이 부족합니다.');
    }
    
    const challenges = storage.getChallenges();
    if (challenges.some(c => c.id === challenge.id)) return;

    storage.setUser({ ...user, balance: user.balance - challenge.deposit });
    storage.saveChallenges([...challenges, { ...challenge, startDate: new Date().toISOString() }]);
  },

  getPosts: (): Post[] => {
    const data = localStorage.getItem(STORAGE_KEYS.POSTS);
    if (data) return JSON.parse(data);
    
    const defaultPosts: Post[] = [
      {
        id: 'p1',
        author: '이지현',
        authorAvatar: 'https://picsum.photos/seed/sarah/100/100',
        content: '벌써 아침 조깅 5일차예요! 코인을 걸어놓으니까 확실히 침대에서 일어나게 되네요. 실패하면 5천 코인이 날아간다는 생각뿐... 😂',
        timestamp: '1시간 전',
        likes: 124,
        comments: 2,
        tag: '운동',
        commentsList: [
          { id: 'c1', author: '박민수', authorAvatar: 'https://picsum.photos/seed/mike/100/100', content: '와 대단해요!', timestamp: '30분 전' },
          { id: 'c2', author: '최지원', authorAvatar: 'https://picsum.photos/seed/amy/100/100', content: '저도 내일부터 시작해요!', timestamp: '10분 전' }
        ]
      },
      {
        id: 'p2',
        author: '박민수',
        authorAvatar: 'https://picsum.photos/seed/mike/100/100',
        content: '기말고사 스터디 매칭 중입니다. 유기화학 집중 공부 중인데 같이 하실 분? 3천 코인 매칭하고 빡세게 달려봅시다!',
        timestamp: '2시간 전',
        likes: 85,
        comments: 1,
        tag: '스터디',
        commentsList: [
          { id: 'c3', author: '이지현', authorAvatar: 'https://picsum.photos/seed/sarah/100/100', content: '저도 참여하고 싶어요!', timestamp: '1시간 전' }
        ]
      },
      {
        id: 'p3',
        author: '최지원',
        authorAvatar: 'https://picsum.photos/seed/amy/100/100',
        content: '물 2L 마시기 성공! AI 인증이 생각보다 꼼꼼하네요. 컵이 비어있으면 칼같이 잡아냄..ㅋㅋ 다들 화이팅!',
        timestamp: '4시간 전',
        likes: 210,
        comments: 0,
        tag: '습관',
        commentsList: []
      }
    ];
    localStorage.setItem(STORAGE_KEYS.POSTS, JSON.stringify(defaultPosts));
    return defaultPosts;
  },

  addComment: (postId: string, comment: PostComment): Post | undefined => {
    const posts = storage.getPosts();
    const postIdx = posts.findIndex(p => p.id === postId);
    if (postIdx !== -1) {
      const post = posts[postIdx];
      if (!post.commentsList) {
        post.commentsList = [];
      }
      post.commentsList.push(comment);
      post.comments += 1;
      localStorage.setItem(STORAGE_KEYS.POSTS, JSON.stringify(posts));
      return post;
    }
    return undefined;
  },

  getChatMessages: (): ChatMessage[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHATS);
    return data ? JSON.parse(data) : [];
  },

  getProofs: (): Proof[] => {
    const data = localStorage.getItem(STORAGE_KEYS.PROOFS);
    return data ? JSON.parse(data) : [];
  },

  addProof: (proof: Proof) => {
    const proofs = storage.getProofs();
    proofs.push(proof);
    localStorage.setItem(STORAGE_KEYS.PROOFS, JSON.stringify(proofs));
    
    const challenges = storage.getChallenges();
    const challengeIdx = challenges.findIndex(c => c.id === proof.challengeId);
    if (challengeIdx !== -1) {
      challenges[challengeIdx].streak += 1;
      challenges[challengeIdx].progress = Math.min(100, challenges[challengeIdx].progress + 5);
      storage.saveChallenges(challenges);
    }
  }
};
