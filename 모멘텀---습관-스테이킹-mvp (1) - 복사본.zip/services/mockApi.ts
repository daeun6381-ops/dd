
import { Post } from '../types';

export const fetchTrendingPosts = async (): Promise<Post[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  return [
    {
      id: 'p1',
      author: '이지현',
      authorAvatar: 'https://picsum.photos/seed/sarah/100/100',
      content: '벌써 아침 조깅 5일차예요! 코인을 걸어놓으니까 확실히 침대에서 일어나게 되네요. 실패하면 5천 코인이 날아간다는 생각뿐... 😂',
      timestamp: '1시간 전',
      likes: 124,
      comments: 18,
      tag: '운동'
    },
    {
      id: 'p2',
      author: '박민수',
      authorAvatar: 'https://picsum.photos/seed/mike/100/100',
      content: '기말고사 스터디 매칭 중입니다. 유기화학 집중 공부 중인데 같이 하실 분? 3천 코인 매칭하고 빡세게 달려봅시다!',
      timestamp: '2시간 전',
      likes: 85,
      comments: 24,
      tag: '스터디'
    },
    {
      id: 'p3',
      author: '최지원',
      authorAvatar: 'https://picsum.photos/seed/amy/100/100',
      content: '물 2L 마시기 성공! AI 인증이 생각보다 꼼꼼하네요. 컵이 비어있으면 칼같이 잡아냄..ㅋㅋ 다들 화이팅!',
      timestamp: '4시간 전',
      likes: 210,
      comments: 32,
      tag: '습관'
    }
  ];
};

export const submitProofToAI = async (imageData: string): Promise<{ success: boolean; score: number }> => {
  // Mocking an AI verification step
  console.log('AI에게 이미지를 보내 확인 중...');
  await new Promise(resolve => setTimeout(resolve, 1500));
  return { success: true, score: 0.98 };
};
